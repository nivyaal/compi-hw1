#!/usr/bin/env python3


import random
import subprocess
import difflib
import os
import argparse


class ColorText:

    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    YELLOW = '\033[93m'
    GREEN = '\033[92m'
    RED = '\033[91m'
    END = '\033[0m'

class Tester:

    TESTS_DIR = os.path.dirname(os.path.realpath(__file__))
    TEST_FILES_DIR = os.path.join(TESTS_DIR, "test_files")
    UTILS_DIR = os.path.join(TESTS_DIR, "utils")
    MAIN_DIR = os.path.join(TESTS_DIR, os.pardir)
    INPUT_FILE = os.path.join(TEST_FILES_DIR, "input")
    OUTPUT_FILE = os.path.join(TEST_FILES_DIR, "output")
    EXPECTED_FILE = os.path.join(TEST_FILES_DIR, "expected")
    DIFF_FILE = os.path.join(TEST_FILES_DIR, "diff")
    CONFIG_FILE = os.path.join(TESTS_DIR, "config")
    ERROR_MSG_FILE = os.path.join(UTILS_DIR, "error_msg.txt")
    BASIC_TOKENS_FILE = os.path.join(UTILS_DIR, "basic_tokens.txt")
    BINOP_TOKEN_FILE = os.path.join(UTILS_DIR, "binop_token.txt")
    RELOP_TOKEN_FILE = os.path.join(UTILS_DIR, "relop_token.txt")
    UNDEFINED_LEXEMES_FILE = os.path.join(UTILS_DIR, "undefined_lexemes.txt")
    BASIC_TOKENS_DICT = {}
    BINOP_TOKEN_LIST = []
    RELOP_TOKEN_LIST = []
    PRINTABLE_CHARS = []
    HEX_CHARS = []
    SPECIAL_STRING_CHARS = []
    UNDEFINED_LEXEMES = []
    with open(CONFIG_FILE, 'r') as config_file:
        next_line = config_file.readline().strip('\n')
        assert next_line.startswith("NUM_OF_TOKENS="), "Error: config file"
        GENERATED_TOKENS = int(next_line.replace("NUM_OF_TOKENS=", ""))
        next_line = config_file.readline().strip('\n')
        assert next_line.startswith("NUM_OF_TESTS="), "Error: config file"
        GENERATED_FILES = int(next_line.replace("NUM_OF_TESTS=", ""))
        next_line = config_file.readline().strip('\n')
        assert next_line.startswith("EXEC_FILE="), "Error: config file"
        EXEC_FILE = next_line.replace("EXEC_FILE=", "")
        COMP_CMD = []
        for i in [1,2]:
            next_line = config_file.readline().strip('\n')
            assert next_line.startswith(f"COMP_CMD_{i}="), "Error: config file"
            COMP_CMD.append(next_line.replace(f"COMP_CMD_{i}=", "").split())
        next_line = config_file.readline().strip('\n')
        assert next_line.startswith("TOKEN_TYPES="), "Error: config file"
        TOKEN_TYPES = next_line.replace("TOKEN_TYPES=", "").split()
    WHITESPACES = [' ', '\t', '\n', '\r']
    NEW_LINE = ['\n', '\r']
    FAILED_TESTS_ERROR_MSG = """
Please check the diff files in the tests/test_files directory.
You can do so by running the tester with the following flag:
--show_diff <test_num>

For instance:
tests/tester.py --show_diff 8

In order to compile again and run a specific test without generating
any new input files run the tester with the following flags:
--compile --run_test <test_num>

For instance:
tests/tester.py --compile --run_test 4
"""
    EXEC_FILE_FULL_PATH = os.path.join(MAIN_DIR, EXEC_FILE)
    RUN_TEST_CMD = [EXEC_FILE_FULL_PATH]
    ERROR_TYPES = [
        "ERROR_UNDEFINED_LEXEME",
        "ERROR_STRING_UNEXPECTED_END",
        "ERROR_STRING_UNDEFINED_ESCAPE_SEQUENCE"
    ]

    @staticmethod
    def colored_print(str, color, new_line):
        if color == "RED":
            print(f"{ColorText.RED}{str}{ColorText.END}", end='', flush=True)
        elif color == "GREEN":
            print(f"{ColorText.GREEN}{str}{ColorText.END}", end='', flush=True)
        elif color == "YELLOW":
            print(f"{ColorText.YELLOW}{str}{ColorText.END}", end='', flush=True)
        elif color == "MAGENTA":
            print(f"{ColorText.MAGENTA}{str}{ColorText.END}", end='', flush=True)
        elif color == "DEFAULT":
            print(str, end='', flush=True)
        if new_line:
            print('', flush=True)

    @staticmethod
    def calc_printed_spaces(file_index):
        spaces = ' ' * (13 - len(str(file_index)))
        return spaces

    @staticmethod
    def get_args():
        parser = argparse.ArgumentParser()
        parser.add_argument("-c", "--compile",
                            action="store_true",
                            default=False,
                            help="compile source files before running tests")
        parser.add_argument("-r", "--run_test",
                            default="all",
                            help="run test on specific input file")
        parser.add_argument("-k", "--keep_files",
                            action="store_true",
                            default=False,
                            help="don't generate new input files")
        parser.add_argument("-d", "--dont_test",
                            action="store_true",
                            default=False,
                            help="don't run any tests")
        parser.add_argument("-s", "--show_diff",
                            default=None,
                            help="show diff file of specific test")
        parser.add_argument("-e", "--errors",
                            action="store_true",
                            default=False,
                            help="generate negative tests")
        return parser.parse_args()

    @classmethod
    def print_diff_file(cls, diff_file_num):
        diff_file_name = cls.DIFF_FILE + f"_{diff_file_num}.txt"
        if not os.path.isfile(diff_file_name):
            cls.colored_print("File does not exist!\n", "RED", new_line=True)
        else:
            with open(diff_file_name, 'r') as diff_file:
                cls.colored_print("\nDiff file location:", "YELLOW", new_line=True)
                cls.colored_print(diff_file_name, "DEFAULT", new_line=True)
                cls.colored_print("\nPrinting diff file...", "YELLOW", new_line=True)
                cls.colored_print(diff_file.read(), "DEFAULT", new_line=True)
        exit()

    @classmethod
    def clean_env(cls):
        current_dir = os.getcwd()
        os.chdir(cls.TEST_FILES_DIR)
        for file_to_delete in os.listdir(cls.TEST_FILES_DIR):
            os.remove(file_to_delete)
        os.chdir(current_dir)

    @classmethod
    def generate_basic_tokens_dict(cls):
        with open(cls.BASIC_TOKENS_FILE) as basic_tokens_file:
            line_number = 0
            for next_line in basic_tokens_file:
                next_line = next_line.strip('\n').split()
                token_name = next_line[0]
                token_value = next_line[1]
                cls.BASIC_TOKENS_DICT[line_number] = [token_name, token_value]
                line_number += 1

    @classmethod
    def generate_binop_token_list(cls):
        with open(cls.BINOP_TOKEN_FILE, 'r') as binop_token_file:
            for next_line in binop_token_file:
                cls.BINOP_TOKEN_LIST.append(next_line.strip('\n'))

    @classmethod
    def generate_relop_token_list(cls):
        with open(cls.RELOP_TOKEN_FILE, 'r') as relop_token_file:
            for next_line in relop_token_file:
                cls.RELOP_TOKEN_LIST.append(next_line.strip('\n'))

    @classmethod
    def generate_printable_chars_list(cls):
        low_limit = int('20', 16)
        high_limit = int('7E', 16)
        for printable_char in range(low_limit, high_limit + 1):
            cls.PRINTABLE_CHARS.append(chr(printable_char))
        cls.PRINTABLE_CHARS.append("\t")
        cls.PRINTABLE_CHARS.remove("\\")
        cls.PRINTABLE_CHARS.remove("\"")

    @classmethod
    def generate_hex_chars_list(cls):
        for right_digit in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F']:
            for left_digit in ['0', '1', '2', '3', '4', '5', '6', '7']:
                cls.HEX_CHARS.append("\\x" + left_digit + right_digit)

    @classmethod
    def generate_special_string_chars_list(cls):
        cls.SPECIAL_STRING_CHARS = ["\\n", "\\r", "\\t", "\\\\", "\\0", "\\\""]

    @classmethod
    def generate_undefined_lexemes_list(cls):
        with open(cls.UNDEFINED_LEXEMES_FILE, 'r') as undefined_lexemes_file:
            for line in undefined_lexemes_file:
                lexeme = chr(int(line.strip('\n')))
                cls.UNDEFINED_LEXEMES.append(lexeme)

    @classmethod
    def set_vars(cls):
        cls.generate_basic_tokens_dict()
        cls.generate_binop_token_list()
        cls.generate_relop_token_list()
        cls.generate_printable_chars_list()
        cls.generate_hex_chars_list()
        cls.generate_special_string_chars_list()
        cls.generate_undefined_lexemes_list()
        cls.colored_print("     DONE", "GREEN", new_line=True)

    @classmethod
    def prepare_env(cls, args):
        cls.colored_print("Preparing environment...", "MAGENTA", new_line=False)
        if (not args.keep_files) and (args.run_test == "all"):
            Tester.clean_env()
        Tester.set_vars()

    @classmethod
    def get_random_basic_token(cls):
        random_index = random.randint(0, len(cls.BASIC_TOKENS_DICT) - 1)
        random_dict_item = cls.BASIC_TOKENS_DICT.get(random_index)
        return random_dict_item[0], random_dict_item[1], random_dict_item[1]

    @classmethod
    def get_random_binop_token(cls):
        binop_token_value = random.choice(cls.BINOP_TOKEN_LIST)
        return "BINOP", binop_token_value, binop_token_value

    @classmethod
    def get_random_relop_token(cls):
        relop_token_value = random.choice(cls.RELOP_TOKEN_LIST)
        return "RELOP", relop_token_value, relop_token_value

    @classmethod
    def get_random_comment_token(cls):
        length = random.randint(0, 100)
        comment_content = "//"
        low_limit = int('00', 16)
        high_limit = int('7F', 16)
        for _ in range(length):
            while True:
                random_char = chr(random.randint(low_limit, high_limit))
                if random_char != '\n' and random_char != '\r':
                    break
            comment_content += random_char
        comment_content += random.choice(cls.NEW_LINE)
        return "COMMENT", comment_content, "//"

    @classmethod
    def is_id_legal(cls, id_value):
        for i in range(len(cls.BASIC_TOKENS_DICT)):
            current_value = (cls.BASIC_TOKENS_DICT[i])[1]
            if current_value == id_value:
                return False
        return True

    @classmethod
    def get_random_id_token(cls):
        while True:
            big_letter_low_limit = int('41', 16)
            big_letter_high_limit = int('5A', 16)
            little_letter_low_limit = int('61', 16)
            little_letter_high_limit = int('7A', 16)
            digit_low_limit = int('30', 16)
            digit_high_limit = int('39', 16)
            first_letter_type = random.choice(["BIG", "LITTLE"])
            if first_letter_type == "BIG":
                first_letter = chr(random.randint(big_letter_low_limit, big_letter_high_limit))
            else: # first_letter_type == "LITTLE"
                first_letter = chr(random.randint(little_letter_low_limit, little_letter_high_limit))
            id_value = first_letter
            length = random.randint(0, 100)
            for _ in range(length):
                char_type = random.choice(["BIG_LETTER", "LITTLE_LETTER", "DIGIT"])
                if char_type == "BIG_LETTER":
                    id_value += chr(random.randint(big_letter_low_limit, big_letter_high_limit))
                elif char_type == "LITTLE_LETTER":
                    id_value += chr(random.randint(little_letter_low_limit, little_letter_high_limit))
                else: # char_type == "DIGIT"
                    id_value += chr(random.randint(digit_low_limit, digit_high_limit))
            if cls.is_id_legal(id_value):
                break
        return "ID", id_value, id_value

    @classmethod
    def get_random_num_token(cls):
        digits = [*range(0,10)]
        first_digit = random.choice(digits)
        num_value = str(first_digit)
        if first_digit != 0:
            length = random.randint(0, 10)
            for _ in range(length):
                num_value += str(random.choice(digits))
        return "NUM", num_value, num_value

    @classmethod
    def get_parsed_char(cls, c):
        parsed_char = c.replace("\\n", "\n")
        if parsed_char != c:
            return parsed_char
        parsed_char = c.replace("\\r", "\r")
        if parsed_char != c:
            return parsed_char
        parsed_char = c.replace("\\t", "\t")
        if parsed_char != c:
            return parsed_char
        parsed_char = c.replace("\\0", "\0")
        if parsed_char != c:
            return parsed_char
        parsed_char = c.replace("\\\"", "\"")
        if parsed_char != c:
            return parsed_char
        parsed_char = c.replace("\\\\", "\\")
        if parsed_char != c:
            return parsed_char
        if c.startswith("\\x"):
            parsed_char = chr(int(c[2:4], 16))
        return parsed_char

    @classmethod
    def get_random_string_char(cls):
        char_type = random.choice(["PRINTABLE", "HEX", "SPECIAL"])
        if char_type == "PRINTABLE":
            random_char = random.choice(cls.PRINTABLE_CHARS)
        elif char_type == "HEX":
            random_char = random.choice(cls.HEX_CHARS)
        else: # char_type == "SPECIAL"
            random_char = random.choice(cls.SPECIAL_STRING_CHARS)
        return random_char, cls.get_parsed_char(random_char)

    @classmethod
    def get_random_string_token(cls):
        length = random.randint(0, 100)
        string_content_input = '"'
        string_content_expected = ''
        for _ in range(length):
            next_char_input, next_char_expected = cls.get_random_string_char()
            string_content_input += next_char_input
            string_content_expected += next_char_expected
        string_content_input += '"'
        return "STRING", string_content_input, string_content_expected

    @classmethod
    def get_random_token(cls):
        token_type = random.choice(cls.TOKEN_TYPES)
        if token_type == "BASIC":
            return cls.get_random_basic_token()
        elif token_type == "BINOP":
            return cls.get_random_binop_token()
        elif token_type == "RELOP":
            return cls.get_random_relop_token()
        elif token_type == "COMMENT":
            return cls.get_random_comment_token()
        elif token_type == "ID":
            return cls.get_random_id_token()
        elif token_type == "NUM":
            return cls.get_random_num_token()
        elif token_type == "STRING":
            return cls.get_random_string_token()
        else:
            cls.colored_print("\nError: Unkown token type!\n", "RED", new_line=True)
            exit()

    @classmethod
    def get_random_whitespace(cls):
        return random.choice(cls.WHITESPACES)

    @classmethod
    def get_random_undefined_lexeme(cls):
        return random.choice(cls.UNDEFINED_LEXEMES)

    @classmethod
    def generate_random_error(cls):
        error_type = random.choice(cls.ERROR_TYPES)
        if error_type == "ERROR_UNDEFINED_LEXEME":
            undefined_lexeme = cls.get_random_undefined_lexeme()
            error_expected_str = "Error " + undefined_lexeme + "\n"
            error_input = undefined_lexeme
            return error_expected_str, error_input
        elif error_type == "ERROR_STRING_UNEXPECTED_END":
            error_expected_str = "Error unclosed string\n"
            _, error_input, _ = cls.get_random_string_token()
            error_input = error_input[:-1] + "\n" + error_input[-1]
            return error_expected_str, error_input
        elif error_type == "ERROR_STRING_UNDEFINED_ESCAPE_SEQUENCE":
            error_expected_str = "Error undefined escape sequence " + "xF5" + "\n"
            _, error_input_perfix, _ = cls.get_random_string_token()
            _, error_input_suffix, _ = cls.get_random_string_token()
            error_input = error_input_perfix[:-1] + "\\xF5" + error_input_suffix[1:]
            return error_expected_str, error_input

    @classmethod
    def generate_single_file(cls, file_index, check_errors):
        input_file_name = cls.INPUT_FILE + '_' + str(file_index) + ".txt"
        expected_file_name = cls.EXPECTED_FILE + '_' + str(file_index) + ".txt"
        generated_tokens_counter = 0;
        if check_errors:
            error_location = random.randint(0, cls.GENERATED_TOKENS)
        else:
            error_location = cls.GENERATED_TOKENS + 1
        with open(input_file_name, 'w') as input_file:
            with open(expected_file_name, 'w') as expected_file:
                current_line_number = 1
                for _ in range(cls.GENERATED_TOKENS):
                    whitespace = cls.get_random_whitespace()
                    if check_errors and error_location == generated_tokens_counter:
                        error_expected_str, error_input = cls.generate_random_error()
                        input_line = error_input
                        expected_line = error_expected_str
                    else: # generate a valid token
                        token_name, token_value_input, token_value_expected = cls.get_random_token()
                        input_line = token_value_input
                        expected_line = str(current_line_number) + " "
                        expected_line += token_name + " "
                        expected_line += token_value_expected + "\n"
                        if token_name == "COMMENT" and token_value_input.endswith("\n"):
                            current_line_number += 1
                    if error_location >= generated_tokens_counter:
                        expected_file.write(expected_line)
                    input_file.write(input_line)
                    input_file.write(whitespace)
                    if whitespace == "\n":
                        current_line_number += 1
                    generated_tokens_counter += 1

    @classmethod
    def generate_files(cls, check_errors):
        cls.colored_print("Generating files...", "MAGENTA", new_line=False)
        for i in range(cls.GENERATED_FILES):
            cls.generate_single_file(i, check_errors)
        cls.colored_print("          DONE", "GREEN", new_line=True)

    @classmethod
    def compile(cls, compile, dont_test):
        if not compile:
            if not dont_test:
                if not os.path.isfile(cls.EXEC_FILE_FULL_PATH):
                    cls.colored_print("Execution file does not exist!", "RED", new_line=True)
                    exit()
                else:
                    return
            else:
                return
        cls.colored_print("Running flex command...", "MAGENTA", new_line=False)
        completed_proc = subprocess.run(cls.COMP_CMD[0],
                                        stdout=subprocess.DEVNULL,
                                        stderr=subprocess.DEVNULL)
        if completed_proc.returncode == 0:
            cls.colored_print("      PASSED", "GREEN", new_line=True)
        else:
            cls.colored_print("      FAILED", "RED", new_line=True)
            cls.colored_print("Printing errors:", "YELLOW", new_line=True)
            subprocess.run(cls.COMP_CMD[0])
            exit()
        cls.colored_print("Running g++ command...", "MAGENTA", new_line=False)
        completed_proc = subprocess.run(cls.COMP_CMD[1],
                                        stdout=subprocess.DEVNULL,
                                        stderr=subprocess.DEVNULL)
        if completed_proc.returncode == 0:
            cls.colored_print("       PASSED", "GREEN", new_line=True)
        else:
            cls.colored_print("       FAILED", "RED", new_line=True)
            cls.colored_print("Printing errors:", "YELLOW", new_line=True)
            subprocess.run(cls.COMP_CMD[1])
            exit()

    @classmethod
    def run_single_test(cls, input_file_name, output_file_name):
        with open(input_file_name, 'r') as input_file:
            with open(output_file_name, 'w') as output_file:
                subprocess.run(cls.RUN_TEST_CMD,
                                stdin=input_file,
                                stdout=output_file,
                                stderr=output_file)

    @classmethod
    def check_diff_lines(cls, diff_file_name, diff_lines, file_index):
        spaces = cls.calc_printed_spaces(file_index)
        if len(diff_lines) == 0:
            cls.colored_print(f"{spaces}PASSED", "GREEN", new_line=True)
            return False
        else:
            cls.colored_print(f"{spaces}FAILED", "RED", new_line=True)
            with open(diff_file_name, 'w') as diff_file:
                for line in diff_lines:
                    diff_file.write(line + '\n')
            return True

    @classmethod
    def check_diff_single_file(cls, output_file_name, expected_file_name,
                                diff_file_name, file_index):
        diff_lines = []
        with open(output_file_name, 'r') as output_file:
            with open(expected_file_name, 'r') as expected_file:
                output_str = output_file.read().strip().splitlines()
                expected_str = expected_file.read().strip().splitlines()
                for line in difflib.unified_diff(output_str,
                                                    expected_str,
                                                    fromfile=output_file_name,
                                                    tofile=expected_file_name,
                                                    lineterm=''):
                    diff_lines.append(line)
        is_test_failed = cls.check_diff_lines(diff_file_name, diff_lines, file_index)
        return is_test_failed

    @classmethod
    def run_tests(cls, test_to_run):
        failed_tests_counter = 0
        for file_index in range(cls.GENERATED_FILES):
            if test_to_run != "all" and test_to_run != str(file_index):
                continue
            input_file_name = cls.INPUT_FILE + '_' + str(file_index) + ".txt"
            output_file_name = cls.OUTPUT_FILE + '_' + str(file_index) + ".txt"
            expected_file_name = cls.EXPECTED_FILE + '_' + str(file_index) + ".txt"
            diff_file_name = cls.DIFF_FILE + '_' + str(file_index) + ".txt"
            cls.colored_print(f"Running test {file_index}...", "MAGENTA", new_line=False)
            cls.run_single_test(input_file_name,
                                output_file_name)
            is_test_failed = cls.check_diff_single_file(output_file_name,
                                                        expected_file_name,
                                                        diff_file_name,
                                                        file_index)
            if is_test_failed:
                failed_tests_counter += 1
        if test_to_run == "all":
            if failed_tests_counter == 0:
                cls.colored_print("\nAll tests passed\n", "GREEN", new_line=True)
            else:
                cls.colored_print(f"\n{failed_tests_counter} tests failed!", "RED", new_line=True)
                cls.colored_print(cls.FAILED_TESTS_ERROR_MSG, "YELLOW", new_line=True)


def main():
    args = Tester.get_args()
    if args.show_diff:
        Tester.print_diff_file(args.show_diff)
    Tester.prepare_env(args)
    if (not args.keep_files) and (args.run_test == "all"):
        Tester.generate_files(args.errors)
    Tester.compile(args.compile, args.dont_test)
    if not args.dont_test:
        Tester.run_tests(args.run_test)


if __name__ == '__main__':
    main()
